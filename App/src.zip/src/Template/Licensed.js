import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import React from 'react';
import {useTheme} from '@react-navigation/native';
import useStore from '../store';

const Licensed = ({navigation}) => {
  const Data = [
    {id: '1', source: require('../assets/Savage.png'), selected: false},
    {id: '2', source: require('../assets/Relatable.png'), selected: false},
    {id: '3', source: require('../assets/Dank.png'), selected: false},
    {id: '4', source: require('../assets/Shitpost.png'), selected: false},
    {id: '5', source: require('../assets/Movies.png'), selected: false},
    {id: '6', source: require('../assets/Wholesome.png'), selected: false},
    {id: '7', source: require('../assets/Anime.png'), selected: false},
    {id: '8', source: require('../assets/Desi.png'), selected: false},
    {id: '9', source: require('../assets/Webseries.png'), selected: false},
  ];
  const {colors} = useTheme();
  const {dark, toggleTheme} = useStore();

  const [select, setSelect] = React.useState(Data);
  //   const [leastCount, setLeastCount] = React.useState([]);
  console.log('selectedItem', select.source);
  const handleOnpress = imageId => {
    navigation.navigate('Licenseds', {imageId});
    // const newItem = select.map(val => {
    //   if (val.id === item.id) {
    //     return {...val, selected: !val.selected};
    //   } else {
    //     return val;
    //   }
    // });
    // // setLeastCount(() => newItem.filter(data => data.selected === true));
    // setSelect(newItem);
  };
  return (
    <ScrollView style={{flex: 1, backgroundColor: colors.color_PageColor}}>
      <View style={styles.flatlist}>
        <FlatList
          data={select}
          keyExtractor={item => item.id}
          renderItem={({item}) => {
            return (
              <View>
                <TouchableOpacity onPress={() => handleOnpress(item.id)}>
                  <Image source={item.source} style={styles.image} />
                  {/* {item.selected === true ? (
                    <Image
                      source={require('../assets/Check2.png')}
                      style={{
                        width: '20%',
                        height: 25,
                        position: 'absolute',
                        // marginLeft: 7,
                        right: 0,
                        borderRadius: 50,
                      }}
                    />
                  ) : null} */}
                </TouchableOpacity>
              </View>
            );
          }}
          numColumns={3}
        />
      </View>
    </ScrollView>
  );
};

export default Licensed;

const styles = StyleSheet.create({
  flatlist: {
    marginTop: 10,
    alignItems: 'center',
  },
  image: {
    margin: 2,
    // flex: 1,
  },
});
