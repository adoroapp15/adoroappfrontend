import * as React from 'react';
import Svg, {Path} from 'react-native-svg';
const SharePost = ({color}) => (
  <Svg
    xmlns="http://www.w3.org/2000/svg"
    width={24}
    height={24}
    fill="none"
    viewBox="0 0 24 24"
    >
    <Path
      stroke={color}
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={1.5}
      d="M16.96 6.17c2 1.39 3.38 3.6 3.66 6.15m-17.13.05a8.601 8.601 0 0 1 3.6-6.15m1.1 14.72c1.16.59 2.48.92 3.87.92 1.34 0 2.6-.3 3.73-.85M12.06 7.7a2.78 2.78 0 1 0 0-5.56 2.78 2.78 0 0 0 0 5.56ZM4.83 19.92a2.78 2.78 0 1 0 0-5.56 2.78 2.78 0 0 0 0 5.56Zm14.34 0a2.78 2.78 0 1 0 0-5.56 2.78 2.78 0 0 0 0 5.56Z"
    />
  </Svg>
);
export default SharePost;
