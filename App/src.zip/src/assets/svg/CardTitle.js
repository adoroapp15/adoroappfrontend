import * as React from 'react';
import Svg, {Path} from 'react-native-svg';
const CardTitle = ({color}) => (
  <Svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} fill={color}>
    <Path d="M5 10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2Zm14 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2Zm-7 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2Z" />
  </Svg>
);
export default CardTitle;
