// import React from 'react';
// import axios from 'axios';
// import {Alert, ScrollView} from 'react-native';
// import {
//   StyleSheet,
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
// } from 'react-native';
// import LinearGradient from 'react-native-linear-gradient';
// import FontFamily from '../common/components/FontFamily';
// import {useState} from 'react';
// import {config} from '../config';
// const Signup = ({navigation}) => {
//   const [number, onChangeNumber] = React.useState('');
//   const [fullName, onChangeFullName] = React.useState('');
//   const [userName, onChangeUserName] = React.useState('');
//   const [numberError, setNumberError] = React.useState(false);
//   const [fullNameError, setFullNameError] = React.useState(false);
//   const [userNameError, setUserNameError] = React.useState(false);
//   const [isButtonDisabled, setButtonDisabled] = useState(false);
 
//   const handleUsernameChange = text => {
//     const formattedText = text.replace(/\s/g, '');
//     onChangeUserName(formattedText.slice(0, 30)); // Limit to 30 characters
//   };
 
//   const handleFullNameChange = text => {
//     onChangeFullName(text.slice(0, 30)); // Limit to 30 characters
//   };
 
//   const handleNumberChange = text => {
//     const formattedText = text.replace(/[^0-9]/g, ''); // Remove non-numeric characters
//     onChangeNumber(formattedText.slice(0, 10)); // Limit to 10 digits
//   };
 
//   const handleOTP = async () => {
//     try {
//       if (!number) {
//         setNumberError(true);
//       } else {
//         setNumberError(false);
//       }
 
//       if (!fullName) {
//         setFullNameError(true);
//       } else {
//         setFullNameError(false);
//       }
//       if (!userName) {
//         setUserNameError(true);
//       } else {
//         setUserNameError(false);
//       }
//       if (!number || !fullName || !userName) {
//         return false;
//       }
//       console.log('attempting to hit the api');
//       // const response = await axios.post(
//       //   'http://10.0.2.2:8000/app/user/generateotp',
 
//       //   {
//       //     mobileNo: number,
//       // });
//       setButtonDisabled(true);
//       const response = await axios.post(
//         `${config.production}/app/user/generateotp`,
//         {
//           mobileNo: number,
//           userName: userName,
//         },
//       );
 
//       console.log('ssss', response);
 
//       if (response.data.status === 200) {
//         navigation.navigate('OTPScreen', {
//           mobileNo: number,
//           username: userName,
//           fullName: fullName,
//         });
//       } else {
//         Alert.alert(response.data.msg);
//       }
//       setButtonDisabled(false);
//     } catch (error) {
//       console.log('errr', error);
//       Alert.alert('Error', 'Failed to connect to the server.');
//       setButtonDisabled(false);
//     }
//   };
//   return (
//     <ScrollView style={styles.container}>
//       <View>
//         <Text style={styles.text}>Welcome Creator</Text>
//         <Text style={styles.text2}>Join the world of creators</Text>
 
//         <TextInput
//           style={styles.input}
//           onChangeText={handleFullNameChange}
//           value={fullName}
//           placeholder="Full Name"
//           placeholderTextColor="#6F7F92"
//         />
//         {fullNameError ? (
//           <Text style={styles.errorText}>Please enter Full Name*</Text>
//         ) : null}
 
//         <TextInput
//           style={styles.input}
//           onChangeText={handleUsernameChange}
//           value={userName}
//           placeholderTextColor="#6F7F92"
//           placeholder="User Name"
//         />
//         {userNameError ? (
//           <Text style={styles.errorText}>Please enter User Name*</Text>
//         ) : null}
 
//         <TextInput
//           style={styles.input}
//           onChangeText={handleNumberChange}
//           value={number}
//           placeholder="Enter Your Number"
//           keyboardType="numeric"
//           placeholderTextColor="#6F7F92"
//         />
//         {numberError ? (
//           <Text style={styles.errorText}>Please enter valide Number*</Text>
//         ) : null}
//         <View style={styles.button}>
//           <TouchableOpacity disabled={isButtonDisabled} onPress={handleOTP}>
//             <LinearGradient
//               colors={
//                 isButtonDisabled
//                   ? ['#f0f0f0', '#e0e0e0']
//                   : [
//                       'rgba(0,255,255,0.4)',
//                       'rgba(255,192,203,1)',
//                       'rgba(255,255,0,0.5)',
//                     ]
//               }
//               start={{x: 0, y: 0}}
//               end={{x: 1, y: 1}}
//               style={{padding: 15, alignItems: 'center', borderRadius: 10}}>
//               <Text style={{color: 'white', fontWeight: 'bold'}}>GET OTP</Text>
//             </LinearGradient>
//           </TouchableOpacity>
//         </View>
//       </View>
//     </ScrollView>
//   );
// };
 
// const styles = StyleSheet.create({
//   container: {
//     backgroundColor: 'white',
//     flex: 1,
//     // borderRadius: 20,
//     top: 60,
//   },
//   text: {
//     color: '#0D253C',
//     fontSize: 24,
//     // fontFamily: 'Poppins',
//     fontFamily: FontFamily.bold,
//     // fontWeight: '400',
//     lineHeight: 31.2,
//     wordWrap: 'break-word',
//     paddingLeft: 20,
//     paddingRight: 10,
//     marginTop: 30,
//   },
//   text2: {
//     color: '#6F7F92',
//     fontSize: 14,
//     fontFamily: FontFamily.bold,
//     // fontWeight: '500',
//     textTransform: 'capitalize',
//     lineHeight: 18,
//     wordWrap: 'break-word',
//     paddingLeft: 20,
//     marginTop: 10,
//   },
//   text3: {
//     color: '#6F7F92',
//     fontSize: 14,
//     fontFamily: FontFamily.bold,
//     // fontWeight: '600',
//     textTransform: 'capitalize',
//     lineHeight: 24,
//     wordWrap: 'break-word',
//     paddingLeft: 20,
//     marginTop: 2,
//   },
//   input: {
//     color: 'black',
//     fontSize: 16,
//     fontFamily: FontFamily.semibold,
//     textAlignVertical: 'center',
//     fontWeight: '400',
//     lineHeight: 20.8,
//     borderWidth: 1,
//     borderColor: '#F1F1F1',
//     margin: 10,
//     paddingLeft: 10,
//     borderRadius: 10,
//   },
//   button: {
//     borderRadius: 10,
//     height: '30%',
//     marginTop: 15,
//     paddingLeft: 10,
//     paddingRight: 10,
//   },
//   buttonText: {
//     marginLeft: 150,
//     marginTop: 15,
//     color: 'white',
//   },
//   errorText: {
//     color: 'red',
//     marginLeft: 16,
//     marginBottom: 15,
//     fontFamily: FontFamily.semibold,
//   },
// });
 
// export default Signup;
 
import React, {useState, useEffect} from 'react';
import axios from 'axios';
import {Alert, ScrollView} from 'react-native';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  TouchableHighlight,
  Modal,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import FontFamily from '../common/components/FontFamily';
import {config} from '../config';
import {useTheme} from '@react-navigation/native';
import Size from '../common/components/Size';
 
const Signup = ({navigation}) => {
  const {colors} = useTheme();
  const [number, onChangeNumber] = useState('');
  const [referral, setReferral] = useState('');
  const [fullName, onChangeFullName] = useState('');
  const [userName, onChangeUserName] = useState('');
  const [numberError, setNumberError] = useState(false);
  const [fullNameError, setFullNameError] = useState(false);
  const [userNameError, setUserNameError] = useState(false);
  const [isButtonDisabled, setButtonDisabled] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
 
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      // Reset error states when the component receives focus
      resetErrors();
    });
 
    // Clean up the listener
    return unsubscribe;
  }, [navigation]);
 
  const resetErrors = () => {
    setNumberError(false);
    setFullNameError(false);
    setUserNameError(false);
  };
 
  const handleUsernameChange = text => {
    const formattedText = text.replace(/\s/g, '');
    onChangeUserName(formattedText.slice(0, 30).toLowerCase()); // Limit to 30 characters
  };
 
  const handleFullNameChange = text => {
    onChangeFullName(text.slice(0, 30)); // Limit to 30 characters
  };
 
  const handleNumberChange = text => {
    const formattedText = text.replace(/[^0-9]/g, ''); // Remove non-numeric characters
    onChangeNumber(formattedText.slice(0, 10)); // Limit to 10 digits
  };
 
  const handleOTP = async () => {
    try {
      if (!number) {
        setNumberError(true);
      } else {
        setNumberError(false);
      }
 
      if (!fullName) {
        setFullNameError(true);
      } else {
        setFullNameError(false);
      }
 
      if (!userName) {
        setUserNameError(true);
      } else {
        setUserNameError(false);
      }
 
 
      if (!number || !fullName || !userName) {
        return false;
      }
 
      setButtonDisabled(true);
 
      const response = await axios.post(
        `${config.production}/app/user/generateotp`,
        {
          mobileNo: number,
          userName: userName,
          referral
        },
      );
 
      if (response.data.status === 200) {
        // setModalVisible(true);
        setTimeout(() => {
          // setModalVisible(false);
          navigation.navigate('OTPScreen', {
            mobileNo: number,
            username: userName,
            fullName: fullName,
          });
        }, 2000);
      } else {
        Alert.alert(response.data.msg);
      }
 
      setButtonDisabled(false);
    } catch (error) {
      Alert.alert('Error', 'Failed to connect to the server.');
      setButtonDisabled(false);
    }
  };
 
  return (
    <ScrollView
      style={[styles.container, {backgroundColor: colors.color_PageColor}]}>
      <View>
        <Text style={[styles.text, {color: colors.color_Logintext}]}>
          Welcome Creator
        </Text>
        <Text style={[styles.text2, {color: colors.color_Logintext1}]}>
          Join the world of creators
        </Text>
 
        <TextInput
          style={[
            styles.input,
            {
              color: colors.color_TextNormal,
              borderColor: colors.color_InputTxtBorder,
              fontFamily: FontFamily.medium,
            },
          ]}
          onChangeText={handleFullNameChange}
          value={fullName}
          placeholder="Full Name"
          placeholderTextColor={colors.color_PlaceHolderColor}
        />
        {fullNameError ? (
          <Text style={styles.errorText}>Please enter Full Name*</Text>
        ) : null}
 
        <TextInput
          style={[
            styles.input,
            {
              color: colors.color_TextNormal,
              borderColor: colors.color_InputTxtBorder,
              fontFamily: FontFamily.medium,
            },
          ]}
          onChangeText={handleUsernameChange}
          value={userName}
          placeholderTextColor={colors.color_PlaceHolderColor}
          placeholder="User Name"
        />
        {userNameError ? (
          <Text style={styles.errorText}>Please enter User Name*</Text>
        ) : null}
 
        <TextInput
          style={[
            styles.input,
            {
              color: colors.color_TextNormal,
              borderColor: colors.color_InputTxtBorder,
              fontFamily: FontFamily.medium,
            },
          ]}
          onChangeText={handleNumberChange}
          value={number}
          placeholder="Enter Your Number"
          keyboardType="numeric"
          placeholderTextColor={colors.color_PlaceHolderColor}
        />
        {numberError ? (
          <Text style={styles.errorText}>Please enter valid Number*</Text>
        ) : null}
        <TextInput
          style={[
            styles.input,
            {
              color: colors.color_TextNormal,
              borderColor: colors.color_InputTxtBorder,
              fontFamily: FontFamily.medium,
            },
          ]}
          onChangeText={setReferral}
          value={referral}
          placeholder="Provide your referral code "
          keyboardType="numeric"
          placeholderTextColor={colors.color_PlaceHolderColor}
        />
        <View style={styles.button}>
          <TouchableOpacity disabled={isButtonDisabled} onPress={handleOTP}>
            <LinearGradient
              colors={
                isButtonDisabled
                  ? ['#f0f0f0', '#e0e0e0']
                  : [
                      'rgba(0,255,255,0.4)',
                      'rgba(255,192,203,1)',
                      'rgba(255,255,0,0.5)',
                    ]
              }
              start={{x: 0, y: 0}}
              end={{x: 1, y: 1}}
              style={{padding: 15, alignItems: 'center', borderRadius: 10}}>
              <Text
                style={{
                  color: 'white',
                  fontFamily: FontFamily.bold,
                  fontSize: Size.title,
                }}>
                GET OTP
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
      <Modal
        // animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(!modalVisible);
        }}>
        <View style={styles.centeredView}>
          <View
            style={{
              backgroundColor: colors.color_CardBgColor,
              // height: 200,
              margin: 20,
              borderRadius: 20,
              padding: 30,
              gap: 20,
              elevation: 5,
            }}>
            <Text
              style={{
                alignSelf: 'center',
                fontFamily: FontFamily.semibold,
                fontSize: 16,
                textAlign: 'center',
                color: colors.color_CardTxtColor,
              }}>
              Success! Your OTP is sent.
            </Text>
 
            <TouchableHighlight
              style={{...styles.openButton, backgroundColor: '#2196F3'}}
              onPress={() => {
                setModalVisible(!modalVisible);
              }}>
              <Text style={styles.textStyle}>Ok</Text>
            </TouchableHighlight>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
};
 
const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
    // borderRadius: 20,
    top: 60,
  },
  text: {
    fontSize: Size.welcomeText,
    fontFamily: FontFamily.bold,
    // fontWeight: '400',
    lineHeight: 31.2,
    wordWrap: 'break-word',
    paddingLeft: 20,
    paddingRight: 10,
    marginTop: 30,
  },
  text2: {
    fontSize: Size.title,
    fontFamily: FontFamily.semibold,
    // fontWeight: '500',
    textTransform: 'capitalize',
    lineHeight: 18,
    wordWrap: 'break-word',
    paddingLeft: 20,
    marginTop: 10,
  },
  text3: {
    color: '#6F7F92',
    fontSize: 14,
    fontFamily: FontFamily.bold,
    // fontWeight: '600',
    textTransform: 'capitalize',
    lineHeight: 24,
    wordWrap: 'break-word',
    paddingLeft: 20,
    marginTop: 2,
  },
  input: {
    fontSize: Size.inputText,
    fontFamily: FontFamily.semibold,
    textAlignVertical: 'center',
    // fontWeight: '400',
    lineHeight: 20.8,
    borderWidth: 1,
    margin: 10,
    paddingLeft: 10,
    borderRadius: 10,
  },
  button: {
    borderRadius: 10,
    height: '30%',
    marginTop: 15,
    paddingLeft: 10,
    paddingRight: 10,
  },
  buttonText: {
    marginLeft: 150,
    marginTop: 15,
    color: '#fff',
  },
  errorText: {
    color: 'red',
    marginLeft: 16,
    marginBottom: 15,
    fontFamily: FontFamily.semibold,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  openButton: {
    backgroundColor: '#F194FF',
    borderRadius: 10,
    // padding: 10,
    paddingLeft: 20,
    paddingRight: 20,
    paddingTop: 10,
    paddingBottom: 10,
    elevation: 2,
  },
  textStyle: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: FontFamily.semibold,
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
    fontFamily: FontFamily.semibold,
  },
});
 
export default Signup;
 